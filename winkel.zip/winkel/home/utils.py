from django.core.mail import send_mail
from django.conf import settings

def send_welcome_email(to_email, subject, message):
    send_mail(
        subject,  # Email subject
        message,  # Email message
        settings.DEFAULT_FROM_EMAIL,  # From email (configured in your settings.py)
        [to_email],  # To email list
        fail_silently=False,  # If there's an error, it will raise an exception
    )
