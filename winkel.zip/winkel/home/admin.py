from django.contrib import admin
from.models import OTP,Product,Category

# Register your models here.

admin.site.register(OTP)
admin.site.register(Product)
admin.site.register(Category)